#!/bin/sh
(cd .. && ./run_release.sh)
